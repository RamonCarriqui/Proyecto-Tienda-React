import React from "react";
class Carrito extends React.Component {
    constructor(props) {
        super(props);
        if (localStorage['micarrito']) { // Si existe carrito en localStorage lo carga
            this.carrito = JSON.parse(localStorage['micarrito']);
        }else{
            this.carrito = []; // Para que aparezca la tabla vacía al menos
        }

        this.state={ // Actualiza los cambios si se modifican las variables
            carrito: this.carrito,
            cantidad: 1,
            total: 0,
          }
    }
    calcularTotal(){
        let total = 0;
        this.carrito.forEach(objeto => {
          total += objeto.precio * objeto.cantidad;
        });
        return total;
      }

    borrarProducto(index) {
        this.setState({ // Filtra el objeto que va a borrar y actualiza localStorage
            carrito: this.carrito.splice(index, 1)
        })
        localStorage.setItem('micarrito', JSON.stringify(this.carrito));
    }

    vaciarCarrito() { // Iguala carrito a un array vacío y actualiza localStorage
        this.setState({
            carrito: this.carrito = []
        })
        localStorage.setItem('micarrito', JSON.stringify(this.carrito));
    }

    aumentarCantidad(index) {
        let objeto = this.carrito[index]; // Saca el objeto específico
        objeto.cantidad++; // aumentara cantidad
        this.setState({ // Se mete en el objeto con cantidad actualizada
            cantidad: objeto.cantidad,
        })
        this.calcularTotal();
        localStorage.setItem('micarrito', JSON.stringify(this.carrito)); // Actualiza localStorage
    }

    disminuirCantidad(index) { // Lo mismo pero disminuir
        let objeto = this.carrito[index];
        if (objeto.cantidad !== 1) {
            objeto.cantidad--;
            this.setState({
                cantidad: objeto.cantidad,
            })
            this.calcularTotal();
            localStorage.setItem('micarrito', JSON.stringify(this.carrito));
        }
    }


    
    render() {
        const total = this.calcularTotal();
        const carrito = this.carrito.map((objeto, index) => {
            return (
                <tr className="cart_item" key={index}>
                    <td className="product-remove">
                        <input type='button' onClick={() => { this.borrarProducto(index) }} defaultValue="Eliminar producto"></input>
                    </td>
                    <td className="product-name">
                        <span className="amount">{objeto.nombre}</span>
                    </td>
                    <td className="product-price">
                        <span className="amount">{objeto.precio}</span>
                    </td>
                    <td className="product-quantity">
                        <div className="buttons_added">
                            <input type='button' onClick={() => { this.disminuirCantidad(index) }} defaultValue="-" min={1}></input>
                            &nbsp;&nbsp;
                            <span className="amount">{objeto.cantidad}</span>
                            &nbsp;&nbsp;
                            <input type='button' onClick={() => { this.aumentarCantidad(index) }} defaultValue="+"></input>
                        </div>
                    </td>
                    <td className="product-subtotal">
                        <span className="amount">{objeto.cantidad * objeto.precio}</span>
                    </td>
                </tr>

            )
        });

        return (
            <div>
                <table cellSpacing="0" className="shop_table cart">
                    <thead>
                        <tr>
                            <th className="product-remove">Delete</th>
                            <th className="product-name">Product</th>
                            <th className="product-price">Price</th>
                            <th className="product-quantity">Quantity</th>
                            <th className="product-subtotal">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        {carrito}
                    </tbody>
                    <tr>
                        <td><input id='vaciar' type='button' onClick={() => { this.vaciarCarrito() }} defaultValue="Eliminar Carrito"></input><br /></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>{total}</td>

                    </tr>
                </table>
                
            </div>
        );
    }
}

export default Carrito;