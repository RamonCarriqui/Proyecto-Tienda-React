// Contiene todos los productos te la tienda
const producto = [
    {
        id: 1,
        nombre: "Samsung Galaxy S5",
        precio: 700,
        imagen: "img/product-1.jpg",
        stock: 15,
        estilo: "detallesOff",
        cantidad: 1
    },
    {
        id: 2,
        nombre: "Nokia Lumia 1320",
        precio: 899,
        imagen: "img/product-2.jpg",
        stock: 12,
        estilo: "detallesOff",
        cantidad: 1
    },
    {
        id: 3,
        nombre: "LG Leon 2015",
        precio: 400,
        imagen: "img/product-3.jpg",
        stock: 6,
        estilo: "detallesOff",
        cantidad: 1
    },
    {
        id: 4,
        nombre: "Sony Z1",
        precio: 1200,
        imagen: "img/product-4.jpg",
        stock: 3,
        estilo: "detallesOff",
        cantidad: 1
    }
]

export default producto;
