import React from "react";
import Productos from "./Productos";

class Main extends React.Component {
    constructor(props) {
        super(props);
        this.carrito = [];
    }

    introducirProducto(producto) {
        if (localStorage['micarrito']) { // Si existe carrito inserta productos y actualiza localStorage
            this.carrito = JSON.parse(localStorage['micarrito']);
            this.carrito.push(producto);
            localStorage.setItem('micarrito', JSON.stringify(this.carrito));
        } else { // Si no existe añade productos y genera el localStorage
            this.carrito.push(producto);
            localStorage.setItem('micarrito', JSON.stringify(this.carrito));
        }
    }

    render() {
        // this.carrito = [];
        return (
            <div id='main'>

                <Productos productoCarrito={(producto) => this.introducirProducto(producto)} />


            </div>);
    }
}

export default Main;