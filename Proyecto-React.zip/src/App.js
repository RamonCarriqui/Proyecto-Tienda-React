import './App.css';
import React from 'react';
import Main from './components/main/main';
import { Routes, Route, Link } from "react-router-dom";
import Cabecera from './components/estaticos/Cabecera'
import Footer from './components/estaticos/Footer';
import Carrito from './components/Carrito';

function App() {
  return (
    <div>
      <Cabecera />
      <Routes>
        <Route path="/" element={<Main />} />
        <Route path="/cart.html" element={<Carrito />} />
      </Routes>
      <Footer />
    </div>

  );
}

export default App;
