// Import the functions you need from the SDKs you need
import { initializeApp} from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBr-jZB8mXRYk0QLhztxnamjB0MBnBhfXc",
  authDomain: "tiendareact-61c0d.firebaseapp.com",
  projectId: "tiendareact-61c0d",
  storageBucket: "tiendareact-61c0d.appspot.com",
  messagingSenderId: "779537924938",
  appId: "1:779537924938:web:00220906e3c729c8d137b3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const db = getFirestore();

export default db;
